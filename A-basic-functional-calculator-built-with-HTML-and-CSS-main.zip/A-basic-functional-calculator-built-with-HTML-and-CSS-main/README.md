# A-basic-functional-calculator-built-with-HTML-and-CSS
A functional calculator using Html and Css
